package by.kulevets.demociproj.enumeration;

public enum Layer {
    SERVICE, REPOSITORY, CONTROLLER
}
