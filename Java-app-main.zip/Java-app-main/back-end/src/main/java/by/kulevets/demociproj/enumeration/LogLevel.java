package by.kulevets.demociproj.enumeration;

public enum LogLevel {
    INFO, WARN, ERROR, DEBUG;
}
