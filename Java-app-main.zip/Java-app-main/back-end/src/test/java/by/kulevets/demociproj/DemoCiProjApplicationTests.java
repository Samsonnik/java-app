package by.kulevets.demociproj;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCiProjApplicationTests {


}
